<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\GalleryRepository")
 */
class Gallery
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $photo;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $description;

    private $thumbnailpath;
    private $photopath;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Musician", inversedBy="uploadedphotos")
     */
    private $musician;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $type;

    public function __toString() {
        return $this->photo;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPhoto(): ?string
    {
        return $this->photo;
    }

    public function getThumbnailpath(): ?string
    {
        $url = "https://muske.co.ke/uploads/gallery/thumbs/".$this->photo.".png";

        $this->thumbnailpath = $url;
        return $this->thumbnailpath;

    }

    public function getPhotoPath(): ?string
    {
        $url = "https://muske.co.ke/uploads/gallery/$this->photo";

        $this->photopath = $url;
        return $this->photopath;

    }

    public function setPhoto(?string $photo): self
    {
        $this->photo = $photo;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getMusician(): ?Musician
    {
        return $this->musician;
    }

    public function setMusician(?Musician $musician): self
    {
        $this->musician = $musician;

        return $this;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(?string $type): self
    {
        $this->type = $type;

        return $this;
    }
}
